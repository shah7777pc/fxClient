'use client';

import React from 'react';
import { Card, Text, Heading, Grid, Flex, Background } from '@/once-ui/components';
import TradeHistoryClient from '@/components/history/TradeHistoryClient';
import styles from '@/components/history/TradeHistory.module.scss';

export default function HistoryPage() {
  return (
    <Background fillWidth className={styles.pageContainer}>
      <Flex direction="column" gap="32" padding="32" fillWidth className={styles.fullWidth}>
        <Flex direction="column" gap="8">
          <Heading as="h1">Trade History</Heading>
          <Text onBackground="neutral-medium">View your completed trades and transaction history</Text>
        </Flex>
        
        <TradeHistoryClient />
      </Flex>
    </Background>
  );
} 