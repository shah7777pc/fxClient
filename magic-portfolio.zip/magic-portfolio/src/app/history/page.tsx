'use client';

import React from 'react';
import { Heading, Text, Background, Flex } from '@/once-ui/components';
import TradeHistoryClient from '@/components/history/TradeHistoryClient';

export default function HistoryPage() {
  return (
    <div style={{ width: '100%', maxWidth: 'none' }}>
      <Background fillWidth>
        <Flex direction="column" gap="32" padding="32" fillWidth>
          <Flex direction="column" gap="8">
            <Heading as="h1">Trade History</Heading>
            <Text onBackground="neutral-medium">View your completed trades and transaction history</Text>
          </Flex>
          
          <TradeHistoryClient />
        </Flex>
      </Background>
    </div>
  );
} 