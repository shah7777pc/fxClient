import os
import re
import time
import json
import threading
from datetime import datetime
import asyncio
import websockets
import glob

# Import the MetaTrader 5 package
try:
    import MetaTrader5 as mt5
    MT5_AVAILABLE = True
except ImportError:
    MT5_AVAILABLE = False
    print("MetaTrader 5 package not found. MT5 integration will be disabled.")

class TradeMonitorBackend:
    def __init__(self, log_file, mt5_enabled=True):
        self.log_file = log_file
        self.trades = []
        self.open_positions = {}
        self.closed_positions = []
        self.last_position = 0
        self.monitoring_active = False
        self.monitor_thread = None
        self.connected_clients = set()
        self.status_message = "Ready"
        
        # MT5 settings
        self.mt5_enabled = mt5_enabled and MT5_AVAILABLE
        self.mt5_initialized = False
        self.mt5_symbols = {}  # Map from our symbols to MT5 symbols
        self.mt5_balance = 0.0  # Store the current MT5 balance
        
        # Initialize MT5 connection if enabled
        if self.mt5_enabled:
            self.initialize_mt5()
            
        # Auto-start monitoring
        self.start_monitoring()
        
    def initialize_mt5(self):
        """Initialize connection to MetaTrader 5"""
        try:
            # Initialize MT5 connection
            if not mt5.initialize():
                print(f"Failed to initialize MT5: {mt5.last_error()}")
                self.mt5_initialized = False
                return False
                
            # Set up symbol mapping (our system -> MT5)
            self.mt5_symbols = {
                "GOLD": "XAUUSD",
                "SILVER": "XAGUSD",
                "HKG": "HK50",
                # Add more symbol mappings as needed
            }
            
            # Get initial balance
            self.update_mt5_balance()
            
            print("MetaTrader 5 initialized successfully")
            self.mt5_initialized = True
            return True
        except Exception as e:
            print(f"Error initializing MT5: {str(e)}")
            self.mt5_initialized = False
            return False
    
    def update_mt5_balance(self):
        """Get current account balance from MT5"""
        if not self.mt5_enabled or not self.mt5_initialized:
            return False
            
        try:
            # Get account information
            account_info = mt5.account_info()
            if account_info is not None:
                self.mt5_balance = account_info.balance
                return True
            else:
                print(f"Failed to get account info: {mt5.last_error()}")
                return False
        except Exception as e:
            print(f"Error getting MT5 balance: {str(e)}")
            return False
            
    def mirror_trade_to_mt5(self, trade):
        """Mirror a detected trade to MetaTrader 5"""
        if not self.mt5_enabled or not self.mt5_initialized:
            return False
            
        try:
            # Map our symbol to MT5 symbol
            symbol = trade['symbol']
            mt5_symbol = self.mt5_symbols.get(symbol)
            
            if not mt5_symbol:
                print(f"Symbol mapping not found for {symbol}")
                return False
                
            # Determine order type
            order_type = mt5.ORDER_TYPE_BUY if trade['direction'] == 'B' else mt5.ORDER_TYPE_SELL
            
            # Prepare trade request
            request = {
                "action": mt5.TRADE_ACTION_DEAL,
                "symbol": mt5_symbol,
                "volume": float(trade['volume']) / 100,  # Convert to MT5 lot size
                "type": order_type,
                "price": trade['price'],
                "deviation": 10,  # price deviation in points
                "magic": 123456,  # magic number
                "comment": f"Mirrored from log: {trade['deal_id']}",
                "type_time": mt5.ORDER_TIME_GTC,
                "type_filling": mt5.ORDER_FILLING_FOK,
            }
            
            # Send order
            result = mt5.order_send(request)
            
            if result.retcode == mt5.TRADE_RETCODE_DONE:
                print(f"MT5 order placed successfully: {result.order}")
                # Update balance after trade
                self.update_mt5_balance()
                return True
            else:
                print(f"MT5 order failed: {result.retcode} - {result.comment}")
                return False
                
        except Exception as e:
            print(f"Error sending order to MT5: {str(e)}")
            return False
            
    def close_trade_in_mt5(self, trade_id, symbol, direction):
        """Close a trade in MT5 when it's closed in the log"""
        if not self.mt5_enabled or not self.mt5_initialized:
            return False
            
        try:
            # Get detailed last error information (if any exists from previous operations)
            last_error = mt5.last_error()
            if last_error[0] != 0:
                print(f"MT5 previous error state: {last_error}")
                
            # Find the position in MT5
            positions = mt5.positions_get()
            
            if positions is None or len(positions) == 0:
                print(f"No positions found in MT5. Last error: {mt5.last_error()}")
                return False
                
            mt5_symbol = self.mt5_symbols.get(symbol)
            if not mt5_symbol:
                # Try using the symbol directly if no mapping exists
                mt5_symbol = symbol
                
            print(f"Attempting to close position for symbol {symbol}, MT5 symbol {mt5_symbol}, direction {'BUY' if direction == 'B' else 'SELL'}, trade_id {trade_id}")
            print(f"Total positions in MT5: {len(positions)}")
            
            # Print all available positions for debugging
            print("Available positions in MT5:")
            for pos in positions:
                print(f"Ticket: {pos.ticket}, Symbol: {pos.symbol}, Type: {'BUY' if pos.type == mt5.POSITION_TYPE_BUY else 'SELL'}, Comment: {getattr(pos, 'comment', 'N/A')}")
            
            # Try to close by symbol and direction first (more reliable than comment)
            position_type = mt5.POSITION_TYPE_BUY if direction == 'B' else mt5.POSITION_TYPE_SELL
            
            # Find positions that match our symbol and type
            matching_positions = [
                pos for pos in positions 
                if (pos.symbol == mt5_symbol or pos.symbol == symbol) and pos.type == position_type
            ]
            
            if matching_positions:
                position = matching_positions[0]  # Take the first matching position
                print(f"Found position by symbol and type: {position.ticket}, symbol: {position.symbol}")
                
                # Get current market prices
                tick = mt5.symbol_info_tick(position.symbol)
                if tick is None:
                    print(f"Failed to get price tick for {position.symbol}. Error: {mt5.last_error()}")
                    return False
                    
                close_type = mt5.ORDER_TYPE_SELL if position.type == mt5.ORDER_TYPE_BUY else mt5.ORDER_TYPE_BUY
                close_price = tick.ask if close_type == mt5.ORDER_TYPE_BUY else tick.bid
                
                # Try different filling modes if needed
                for filling_type in [mt5.ORDER_FILLING_FOK, mt5.ORDER_FILLING_IOC, mt5.ORDER_FILLING_RETURN]:
                    print(f"Attempting to close with filling type: {filling_type}")
                    
                    request = {
                        "action": mt5.TRADE_ACTION_DEAL,
                        "symbol": position.symbol,
                        "volume": position.volume,
                        "type": close_type,
                        "position": position.ticket,
                        "price": close_price,
                        "deviation": 20,  # Increased deviation
                        "magic": 123456,
                        "comment": f"Closing mirrored trade {trade_id}",
                        "type_time": mt5.ORDER_TIME_GTC,
                        "type_filling": filling_type,
                    }
                    
                    # Send the close order
                    print(f"Sending close request: {request}")
                    result = mt5.order_send(request)
                    
                    if result is None:
                        print(f"MT5 order_send returned None. Error: {mt5.last_error()}")
                        continue
                        
                    if result.retcode == mt5.TRADE_RETCODE_DONE:
                        print(f"MT5 position closed successfully: {position.ticket}")
                        # Update balance after closing position
                        self.update_mt5_balance()
                        return True
                    else:
                        print(f"MT5 closing failed: {result.retcode} - {result.comment} - Error: {mt5.last_error()}")
                        
                        # If we have a specific dealer rejection, try a market order instead
                        if result.retcode == mt5.TRADE_RETCODE_REQUOTE or result.retcode == mt5.TRADE_RETCODE_PRICE_OFF:
                            print("Trying market order with zero price...")
                            # Use 0 price for market execution
                            request["price"] = 0
                            result = mt5.order_send(request)
                            if result is not None and result.retcode == mt5.TRADE_RETCODE_DONE:
                                print(f"MT5 position closed with market order: {position.ticket}")
                                self.update_mt5_balance()
                                return True
                
                # All filling types failed, try closing with a market order
                print("Trying a market close order...")
                try:
                    result = mt5.Close(position.symbol, ticket=position.ticket)
                    if result:
                        print(f"Successfully closed position using mt5.Close(): {position.ticket}")
                        self.update_mt5_balance()
                        return True
                    else:
                        print(f"Failed to close with mt5.Close(): {mt5.last_error()}")
                except Exception as close_error:
                    print(f"Error with mt5.Close(): {close_error}")
            
            # If we got here, no matching position was found or could be closed
            print(f"Could not close any position for trade {trade_id}, symbol {symbol}, direction {direction}")
            return False
            
        except Exception as e:
            print(f"Error closing position in MT5: {str(e)}")
            import traceback
            traceback.print_exc()
            return False
        
    def start_monitoring(self):
        """Start monitoring for new trades"""
        try:
            # Set last_position to end of file so we only process new entries
            with open(self.log_file, 'r') as file:
                file.seek(0, os.SEEK_END)
                self.last_position = file.tell()
                
            self.monitoring_active = True
            
            # Start monitoring thread
            self.monitor_thread = threading.Thread(target=self.monitor_thread_func)
            self.monitor_thread.daemon = True
            self.monitor_thread.start()
            
            self.status_message = f"Monitoring for new trades" + (" and mirroring to MT5" if self.mt5_enabled and self.mt5_initialized else "")
            
        except Exception as e:
            self.status_message = f"Error: {str(e)}"
            
    def monitor_thread_func(self):
        """Background thread for monitoring the log file"""
        balance_check_counter = 0  # Counter to control how often we check the balance
        
        while self.monitoring_active:
            try:
                # Check if file has been modified
                with open(self.log_file, 'r') as file:
                    file.seek(0, os.SEEK_END)
                    current_position = file.tell()
                    
                    # If file has grown, read new content
                    if current_position > self.last_position:
                        file.seek(self.last_position)
                        new_lines = file.readlines()
                        self.last_position = current_position
                        
                        # Process each new line
                        for line in new_lines:
                            self._process_line(line)
                            
                        # Send updates to all connected WebSocket clients
                        if len(new_lines) > 0:
                            self.status_message = f"Found {len(new_lines)} new entries - {datetime.now().strftime('%H:%M:%S')}"
                            asyncio.run(self.broadcast_updates())
                            
                # Periodically update MT5 balance (every 5 seconds)
                balance_check_counter += 1
                if self.mt5_enabled and self.mt5_initialized and balance_check_counter >= 10:
                    balance_check_counter = 0
                    self.update_mt5_balance()
                    asyncio.run(self.broadcast_updates())
                    
            except Exception as e:
                self.status_message = f"Error: {str(e)}"
                
            # Sleep to prevent high CPU usage
            time.sleep(0.5)
    
    def _process_line(self, line):
        """Process a single log line"""
        # Parse trade entries
        trade_pattern = r'(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d{3}) \{I\} Trader Add Deal (\d+),(B|S),([0-9.]+),([A-Z]+),(\d+),?([^,]*)'
        trade_match = re.search(trade_pattern, line)
        
        if trade_match:
            timestamp, account, direction, price, symbol, volume, ref = trade_match.groups()
            self._register_trade(timestamp, account, direction, float(price), symbol, int(volume), ref)
            return
            
        # Parse deal confirmation
        deal_pattern = r'(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d{3}) \{I\} \d{2}:\d{2}:\d{2} - New Deal Added \((\d+)\)'
        deal_match = re.search(deal_pattern, line)
        
        if deal_match:
            timestamp, deal_id = deal_match.groups()
            self._confirm_deal(timestamp, deal_id)
            return
            
        # Parse position removal (trade closure)
        close_pattern = r'(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d{3}) \{T\} OpenPosition \[Acc\]\[(\d+)\]\[Ref\]\[(\d+)\] removed from contract'
        close_match = re.search(close_pattern, line)
        
        if close_match:
            timestamp, account, ref = close_match.groups()
            self._close_position(timestamp, account, ref)
            return
            
        # Parse position addition
        open_pattern = r'(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d{3}) \{T\} OpenPosition \[Acc\]\[(\d+)\]\[Ref\]\[(\d+)\] added to contract'
        open_match = re.search(open_pattern, line)
        
        if open_match:
            timestamp, account, ref = open_match.groups()
            self._add_position(timestamp, account, ref)
            return
        
        # Parse trade closure (order filled)
        filled_pattern = r'(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d{3}) \{I\} TraderDeal::OnOrderFilled (\d+)'
        filled_match = re.search(filled_pattern, line)
        
        if filled_match:
            timestamp, order_id = filled_match.groups()
            self._mark_as_filled(timestamp, order_id)
            return
            
        # Parse order completed message
        completed_pattern = r'(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d{3}) \{I\} Order (\d+) completed'
        completed_match = re.search(completed_pattern, line)
        
        if completed_match:
            timestamp, order_id = completed_match.groups()
            self._mark_as_filled(timestamp, order_id)
            return
            
        # Parse order canceled message
        canceled_pattern = r'(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d{3}) \{I\} Order (\d+) canceled'
        canceled_match = re.search(canceled_pattern, line)
        
        if canceled_match:
            timestamp, order_id = canceled_match.groups()
            self._mark_as_filled(timestamp, order_id)
            return
            
    def _register_trade(self, timestamp, account, direction, price, symbol, volume, ref):
        """Register a new trade"""
        trade = {
            'timestamp': timestamp,
            'account': account,
            'direction': direction,
            'price': price,
            'symbol': symbol,
            'volume': volume,
            'ref': ref,
            'deal_id': '-1',  # Placeholder until confirmed
            'status': 'pending',
            'is_open': True,
            'mt5_mirrored': False
        }
        self.trades.append(trade)
        
    def _confirm_deal(self, timestamp, deal_id):
        """Confirm a trade with a deal ID"""
        # Find the most recent pending trade
        for trade in reversed(self.trades):
            if trade['status'] == 'pending':
                trade['deal_id'] = deal_id
                trade['status'] = 'confirmed'
                # Don't automatically add to open_positions, wait for the explicit open message
                break
    
    def _add_position(self, timestamp, account, ref):
        """Add a position to the open positions list"""
        # Find the trade with this reference
        for trade in self.trades:
            if trade.get('deal_id') == ref:
                self.open_positions[ref] = trade
                
                # Mirror to MT5 if enabled
                if self.mt5_enabled and self.mt5_initialized and not trade.get('mt5_mirrored', False):
                    if self.mirror_trade_to_mt5(trade):
                        trade['mt5_mirrored'] = True
                break
    
    def _close_position(self, timestamp, account, ref):
        """Close a position"""
        if ref in self.open_positions:
            position = self.open_positions.pop(ref)
            self.closed_positions.append({
                'open': position,
                'close_timestamp': timestamp
            })
            
            # Close in MT5 if mirrored
            if self.mt5_enabled and self.mt5_initialized and position.get('mt5_mirrored', False):
                self.close_trade_in_mt5(position['deal_id'], position['symbol'], position['direction'])
    
    def _mark_as_filled(self, timestamp, order_id):
        """Mark a trade as filled/closed"""
        # Find the trade with this order ID and remove from open positions
        if order_id in self.open_positions:
            position = self.open_positions.pop(order_id)
            self.closed_positions.append({
                'open': position,
                'close_timestamp': timestamp
            })
            
            # Close in MT5 if mirrored
            if self.mt5_enabled and self.mt5_initialized and position.get('mt5_mirrored', False):
                self.close_trade_in_mt5(position['deal_id'], position['symbol'], position['direction'])
            return True
        
        # If not found directly, check if any trade has this as deal_id and mark it as closed
        for ref, position in list(self.open_positions.items()):
            if position['deal_id'] == order_id:
                self.closed_positions.append({
                    'open': position,
                    'close_timestamp': timestamp
                })
                
                # Close in MT5 if mirrored
                if self.mt5_enabled and self.mt5_initialized and position.get('mt5_mirrored', False):
                    self.close_trade_in_mt5(position['deal_id'], position['symbol'], position['direction'])
                
                self.open_positions.pop(ref)
                return True
                
        return False
    
    async def register_client(self, websocket):
        """Register a new WebSocket client"""
        self.connected_clients.add(websocket)
        print(f"New client connected. Total clients: {len(self.connected_clients)}")
        
        # Send initial data to the client
        await self.send_data_to_client(websocket)
        
    async def unregister_client(self, websocket):
        """Unregister a WebSocket client"""
        self.connected_clients.remove(websocket)
        print(f"Client disconnected. Remaining clients: {len(self.connected_clients)}")
        
    async def send_data_to_client(self, websocket):
        """Send current data to a specific client"""
        # Prepare data to send
        data = {
            'status': self.status_message,
            'mt5_status': {
                'connected': self.mt5_initialized,
                'balance': self.mt5_balance
            },
            'open_positions': [
                {
                    'symbol': pos['symbol'],
                    'direction': "BUY" if pos['direction'] == 'B' else "SELL",
                    'status': "Opening" if pos['deal_id'] == '-1' else "Active",
                    'volume': pos['volume'],
                    'price': pos['price'],
                    'deal_id': pos['deal_id'],
                    'timestamp': pos['timestamp'],
                    'mt5_mirrored': pos.get('mt5_mirrored', False)
                } for ref, pos in self.open_positions.items()
            ],
            'closed_positions': [
                {
                    'symbol': closed['open']['symbol'],
                    'direction': "BUY" if closed['open']['direction'] == 'B' else "SELL",
                    'volume': closed['open']['volume'],
                    'price': closed['open']['price'],
                    'deal_id': closed['open']['deal_id'],
                    'open_timestamp': closed['open']['timestamp'],
                    'close_timestamp': closed['close_timestamp'],
                    'mt5_mirrored': closed['open'].get('mt5_mirrored', False)
                } for closed in self.closed_positions[-10:]  # Send only the most recent 10 closed positions
            ]
        }
        
        # Send data as JSON
        await websocket.send(json.dumps(data))
        
    async def broadcast_updates(self):
        """Send updates to all connected clients"""
        # Make a copy of clients to avoid "set changed during iteration" errors
        clients = self.connected_clients.copy()
        
        for websocket in clients:
            try:
                await self.send_data_to_client(websocket)
            except websockets.exceptions.ConnectionClosed:
                # Client disconnected
                await self.unregister_client(websocket)
            except Exception as e:
                print(f"Error sending updates to client: {str(e)}")

async def websocket_handler(websocket, path, trade_monitor):
    """Handle WebSocket connections"""
    # Handle CORS for the websocket connection
    origin = websocket.request_headers.get('Origin', '')
    
    # Print the origin for debugging
    print(f"Connection from origin: {origin}")
    
    # Add CORS headers if needed
    if origin:
        # We could restrict to specific origins here, but for now we'll accept any
        # For production, you'd want to restrict to your Next.js app's domain
        pass
    
    await trade_monitor.register_client(websocket)
    try:
        async for message in websocket:
            # Handle any commands from the client
            try:
                data = json.loads(message)
                command = data.get('command')
                
                # Handle different commands
                if command == 'get_data':
                    await trade_monitor.send_data_to_client(websocket)
                # Add more commands as needed
                
            except json.JSONDecodeError:
                print(f"Received invalid JSON: {message}")
    except websockets.exceptions.ConnectionClosed:
        pass
    finally:
        await trade_monitor.unregister_client(websocket)

async def main():
    # Look for log files in the specified directory
    log_dir = r"C:\Program Files (x86)\EBL\Client Demo\logs"
    
    # Check if the directory exists
    if not os.path.exists(log_dir):
        print(f"Error: Log directory not found: {log_dir}")
        return
    
    # Find the most recent log file
    log_files = glob.glob(os.path.join(log_dir, "SystemLog-*.log"))
    
    if not log_files:
        print(f"Error: No log files found in {log_dir}")
        return
    
    # Sort by modification time (most recent first)
    log_files.sort(key=os.path.getmtime, reverse=True)
    log_file = log_files[0]
    
    print(f"Using log file: {log_file}")
    
    # Create the trade monitor backend
    trade_monitor = TradeMonitorBackend(log_file, mt5_enabled=True)
    
    # Enable CORS for the WebSocket server
    print(f"Starting WebSocket server on ws://localhost:8765")
    server = await websockets.serve(
        lambda ws, path: websocket_handler(ws, path, trade_monitor),
        "localhost", 8765
    )
    
    print(f"WebSocket server started on ws://localhost:8765")
    
    # Keep the server running
    await server.wait_closed()

if __name__ == "__main__":
    try:
        asyncio.run(main())
    finally:
        # Shutdown MT5 when closing the application
        if MT5_AVAILABLE and mt5.initialize():
            mt5.shutdown() 